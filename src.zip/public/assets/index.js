import logo from "./logo.png";

export const logoSVG = logo;
