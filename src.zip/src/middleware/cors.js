import { NextResponse } from "next/server";

export function corsMiddleware(request) {
  const origin = request.headers.get("origin");

  // Thiết lập các header CORS
  const headers = {
    "Access-Control-Allow-Origin": origin || "*", // Cho phép tất cả các origin hoặc origin cụ thể
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS", // Các phương thức được phép
    "Access-Control-Allow-Headers": "Content-Type, Authorization", // Các header được phép
  };

  // Nếu là yêu cầu OPTIONS (preflight), trả về response với headers CORS
  if (request.method === "OPTIONS") {
    return NextResponse.json({}, { headers });
  }

  // Trả về NextResponse với các header CORS
  return NextResponse.next({
    headers,
  });
}
