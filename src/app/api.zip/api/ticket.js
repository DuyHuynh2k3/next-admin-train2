import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export default async function handler(req, res) {
  // Xử lý yêu cầu GET để lấy dữ liệu vé
  if (req.method === "GET") {
    try {
      const tickets = await prisma.ticket.findMany({
        select: {
          ticket_id: true,
          passport: true,
          fullName: true,
          phoneNumber: true,
          email: true,
          train: { select: { train_name: true } },
          startStation: true,
          endStation: true,
          coach_seat: true,
          seattrain: { select: { seat_number: true } },
          price: true,
          trainID: true,
          qr_code: true,
          seatID: true,
          travel_date: true,
          departTime: true, // Lấy đầy đủ DateTime
          arrivalTime: true, // Lấy đầy đủ DateTime
        },
        take: 25, // LIMIT 0, 25
      });

      // Định dạng lại departTime và arrivalTime thành HH:MM
      const formattedTickets = tickets.map((ticket) => ({
        ...ticket,
        departTime: formatTime(ticket.departTime), // Chuyển sang HH:MM
        arrivalTime: formatTime(ticket.arrivalTime), // Chuyển sang HH:MM
      }));

      res.status(200).json(formattedTickets);
    } catch (error) {
      res.status(500).json({ error: "Database query failed" });
    }
  }

  // Xử lý yêu cầu DELETE để xóa vé
  else if (req.method === "DELETE") {
    const { passport } = req.body;

    if (!passport) {
      return res.status(400).json({ error: "Passport is required" });
    }

    try {
      const result = await prisma.ticket.deleteMany({
        where: { passport: passport },
      });

      if (result.count > 0) {
        return res.status(200).json({ message: "Ticket deleted successfully" });
      } else {
        return res.status(404).json({ error: "Ticket not found" });
      }
    } catch (error) {
      console.error("Error deleting ticket:", error);
      return res.status(500).json({ error: "Failed to delete ticket" });
    }
  }

  // Xử lý yêu cầu PUT để cập nhật vé
  else if (req.method === "PUT") {
    const { ticket_id, passport, fullName, phoneNumber, email } = req.body;

    console.log("Received data for update:", {
      ticket_id,
      passport,
      fullName,
      phoneNumber,
      email,
    });

    if (!ticket_id || !passport || !fullName || !phoneNumber || !email) {
      return res.status(400).json({ error: "All fields are required" });
    }

    try {
      // Kiểm tra passport có tồn tại trong bảng Customer không
      const customer = await prisma.customer.findUnique({
        where: { passport: passport },
      });

      if (!customer) {
        return res
          .status(400)
          .json({ error: "Passport does not exist in customer table" });
      }

      // Cập nhật vé
      const updatedTicket = await prisma.ticket.update({
        where: { ticket_id: ticket_id },
        data: {
          passport: passport,
          fullName: fullName,
          phoneNumber: phoneNumber,
          email: email,
        },
      });

      console.log("Ticket updated successfully");
      return res.status(200).json({ message: "Ticket updated successfully" });
    } catch (error) {
      console.error("Error updating ticket:", error);
      if (error.code === "P2025") {
        // Lỗi khi không tìm thấy bản ghi
        return res.status(404).json({ error: "Ticket not found" });
      }
      return res.status(500).json({ error: "Failed to update ticket" });
    }
  }
}

// Hàm định dạng thời gian từ DateTime sang HH:MM
function formatTime(dateTime) {
  if (!dateTime) return null;
  const date = new Date(dateTime);
  const hours = date.getUTCHours().toString().padStart(2, "0"); // Lấy giờ UTC
  const minutes = date.getUTCMinutes().toString().padStart(2, "0"); // Lấy phút UTC
  return `${hours}:${minutes}`;
}
