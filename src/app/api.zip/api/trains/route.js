import mysql from "mysql2";
import { NextResponse } from "next/server";

// Tạo kết nối MySQL
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "trainbooking",
});

// Định nghĩa phương thức GET
// Phương thức GET
export const GET = (req) => {
  const query = `
    SELECT 
        train.trainID,
        train.train_name,
        route.startStation,
        route.endStation,
        schedule.depart_time AS departTime,
        schedule.arrival_time AS arrivalTime,  
        route.price,
        train.total_seats,
        train_recurrence.start_date,  
        train_recurrence.end_date,    
        route.duration,       
        route.route_id,       
        schedule.schedule_id, 
        train_recurrence.days_of_week 
    FROM 
        trainbooking.train AS train
    JOIN 
        trainbooking.schedule AS schedule
        ON train.trainID = schedule.trainID
    JOIN 
        trainbooking.route AS route
        ON schedule.route_id = route.route_id
    JOIN 
        trainbooking.train_recurrence AS train_recurrence
        ON schedule.recurrence_id = train_recurrence.recurrence_id;
  `;

  return new Promise((resolve, reject) => {
    connection.query(query, (err, results) => {
      if (err) {
        reject(new Error("Truy vấn cơ sở dữ liệu thất bại"));
      } else {
        resolve(results);
      }
    });
  })
    .then((results) => {
      // Nếu không có kết quả, trả về một đối tượng JSON trống
      if (results.length === 0) {
        return NextResponse.json(
          { message: "Không có dữ liệu" },
          { status: 404 }
        );
      }
      return NextResponse.json(results);
    })
    .catch((error) => {
      return NextResponse.json({ error: error.message }, { status: 500 });
    });
};

// Phương thức POST - Thêm dữ liệu mới
export const POST = (req) => {
  const { trainID, train_name, startStation, endStation, price, total_seats } =
    req.body;

  const query = `
    INSERT INTO trainbooking.train (trainID, train_name)
    VALUES (?, ?);
  `;

  return new Promise((resolve, reject) => {
    connection.query(query, [trainID, train_name], (err, results) => {
      if (err) {
        reject(new Error("Thêm dữ liệu thất bại"));
      } else {
        resolve(NextResponse.json({ message: "Thêm thành công" }));
      }
    });
  }).catch((error) => {
    return NextResponse.json({ error: error.message }, { status: 500 });
  });
};

// Phương thức PUT - Cập nhật dữ liệu
export const PUT = (req) => {
  const { trainID, train_name, startStation, endStation, price, total_seats } =
    req.body;

  const query = `
    UPDATE trainbooking.train
    SET train_name = ?, startStation = ?, endStation = ?, price = ?, total_seats = ?
    WHERE trainID = ?;
  `;

  return new Promise((resolve, reject) => {
    connection.query(
      query,
      [train_name, startStation, endStation, price, total_seats, trainID],
      (err, results) => {
        if (err) {
          reject(new Error("Cập nhật dữ liệu thất bại"));
        } else {
          resolve(NextResponse.json({ message: "Cập nhật thành công" }));
        }
      }
    );
  }).catch((error) => {
    return NextResponse.json({ error: error.message }, { status: 500 });
  });
};

// Phương thức DELETE - Xóa dữ liệu
// API DELETE - Xóa dữ liệu
export const DELETE = (req) => {
  const { trainID } = req.query; // Lấy trainID từ query params

  const query = `
    DELETE FROM trainbooking.train WHERE trainID = ?;
  `;

  return new Promise((resolve, reject) => {
    connection.query(query, [trainID], (err, results) => {
      if (err) {
        reject(new Error("Xóa dữ liệu thất bại"));
      } else {
        resolve(NextResponse.json({ message: "Xóa thành công" }));
      }
    });
  }).catch((error) => {
    return NextResponse.json({ error: error.message }, { status: 500 });
  });
};
