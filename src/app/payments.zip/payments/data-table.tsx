"use client";

import * as React from "react";
import { FiSearch } from "react-icons/fi";
import axios from "axios";
import styles from "./Table.module.css";
import { ArrowUpDown, ChevronDown, MoreHorizontal } from "lucide-react";
import { flexRender } from "@tanstack/react-table";
import {
  ColumnDef,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export type Train = {
  trainID: string;
  train_name: string;
  startStation: string;
  endStation: string;
  departTime: string;
  arrivalTime: string;
  price: number;
  total_seats: number;
  start_date: Date;
  end_date: Date;
  duration: number;
  route_id: number;
  schedule_id: number;
  recurrence_id?: number;
  days_of_week: string;
  arrival_date: Date; // Thêm arrival_date vào đây
};

export function DataTableTrain() {
  const [trainData, setTrainData] = React.useState<Train[]>([]);
  const [loading, setLoading] = React.useState<boolean>(true);
  const [error, setError] = React.useState<string | null>(null);
  const [isClient, setIsClient] = React.useState(false);
  const [searchText, setSearchText] = React.useState("");
  const [debouncedSearchText, setDebouncedSearchText] =
    React.useState(searchText);
  const [showModal, setShowModal] = React.useState(false);
  const [showModalView, setShowModalView] = React.useState(false);
  const [showModalUpdate, setShowModalUpdate] = React.useState(false);

  const [newTrain, setNewTrain] = React.useState<Train>({
    trainID: "",
    train_name: "",
    startStation: "",
    endStation: "",
    departTime: "",
    arrivalTime: "",
    price: 0, // Khởi tạo với số 0 cho giá trị số
    total_seats: 0, // Khởi tạo với số 0 cho giá trị số
    start_date: new Date(), // Khởi tạo với Date rỗng
    end_date: new Date(), // Khởi tạo với Date rỗng
    duration: 0, // Khởi tạo với số 0 cho duration
    route_id: 0, // Khởi tạo với số 0 cho route_id
    schedule_id: 0, // Khởi tạo với số 0 cho schedule_id
    recurrence_id: 0, // Khởi tạo với số 0 cho recurrence_id
    arrival_date: new Date(),
    days_of_week: "",
  });

  const [selectedTrainView, setSelectedTrainView] =
    React.useState<Train | null>(null); // Fixed type to null initially
  const [selectedTrainUpdate, setSelectedTrainUpdate] =
    React.useState<Train | null>(null); // Fixed type to null initially

  React.useEffect(() => {
    setIsClient(true);
  }, []);

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("../api/trains");
        if (!res.ok) {
          throw new Error("Failed to fetch trains");
        }
        const data = await res.json();
        if (Array.isArray(data)) {
          setTrainData(data);
        } else {
          console.error("Fetched data is not an array:", data);
          setTrainData([]);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        setError("Failed to load data");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  React.useEffect(() => {
    const timer = setTimeout(() => {
      if (debouncedSearchText !== searchText) {
        // Kiểm tra xem giá trị có thay đổi không
        setDebouncedSearchText(searchText);
      }
    }, 300);

    return () => clearTimeout(timer); // Cleanup khi component unmount hoặc searchText thay đổi
  }, [searchText]);

  const filteredData = trainData.filter((item) => {
    const lowercasedSearchText = debouncedSearchText.toLowerCase();
    return (
      (item.trainID &&
        item.trainID.toString().toLowerCase().includes(lowercasedSearchText)) ||
      (item.train_name &&
        item.train_name.toLowerCase().includes(lowercasedSearchText)) ||
      (item.startStation &&
        item.startStation.toLowerCase().includes(lowercasedSearchText)) ||
      (item.endStation &&
        item.endStation.toLowerCase().includes(lowercasedSearchText)) ||
      (item.departTime &&
        item.departTime.toLowerCase().includes(lowercasedSearchText))
    );
  });

  const handleDelete = async (trainID: string) => {
    const confirmDelete = window.confirm(
      "Bạn có chắc muốn xóa chuyến tàu này?"
    );
    if (confirmDelete) {
      try {
        const response = await fetch(`/api/trains?trainID=${trainID}`, {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
          },
        });

        // Kiểm tra xem API có trả về JSON hợp lệ không
        if (response.ok) {
          const data = await response.json(); // Đảm bảo dữ liệu nhận được là JSON
          if (data.message === "Xóa thành công") {
            setTrainData((prevRecords) =>
              prevRecords.filter((train) => train.trainID !== trainID)
            );
            alert("Chuyến tàu đã được xóa thành công!");
          } else {
            alert("Không thể xóa chuyến tàu");
          }
        } else {
          const errorData = await response.json();
          alert(errorData.error || "Lỗi khi xóa chuyến tàu");
        }
      } catch (error) {
        console.error("Error deleting train:", error);
        alert("Có lỗi xảy ra khi xóa chuyến tàu");
      }
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    if (showModalUpdate && selectedTrainUpdate) {
      setSelectedTrainUpdate((prevTrain) => ({
        ...prevTrain!,
        [name]: value,
      }));
    } else {
      setNewTrain((prevTrain) => ({
        ...prevTrain,
        [name]: value,
      }));
    }
  };

  const handleAddTrain = async () => {
    const requiredFields = [
      "trainID",
      "train_name",
      "startStation",
      "endStation",
      "departTime",
      "arrivalTime",
      "price",
      "total_seats",
      "start_date",
      "end_date",
      "duration",
      "route_id",
      "schedule_id",
      "recurrence_id",
      "days_of_week",
    ];

    // Kiểm tra các trường cần thiết
    for (let field of requiredFields) {
      if (!newTrain[field as keyof Train]) {
        alert(`Vui lòng điền đầy đủ thông tin cho trường ${field}!`);
        return;
      }
    }

    try {
      const response = await fetch("/api/trains", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newTrain),
      });

      const data = await response.json();
      if (response.ok) {
        setTrainData((prevRecords) => [...prevRecords, data]);
        alert("Chuyến tàu đã được thêm thành công!");
        setShowModal(false); // Đóng modal
      } else {
        alert(data.error || "Thêm chuyến tàu thất bại");
      }
    } catch (error) {
      console.error("Error adding train:", error);
      alert("Có lỗi xảy ra khi thêm chuyến tàu");
    }
  };

  const handleView = async (trainID: string) => {
    if (showModalView) return; // Tránh việc mở lại modal khi chưa cần thiết

    try {
      const response = await fetch(`/api/trains?trainID=${trainID}`);
      if (response.ok) {
        const data = await response.json();
        setSelectedTrainView(data);
        setShowModalView(true);
      }
    } catch (error) {
      console.error("Lỗi khi xem chuyến tàu:", error);
      alert("Có lỗi xảy ra khi xem chuyến tàu");
    }
  };

  const handleUpdate = (trainID: string) => {
    const selected = trainData.find((train) => train.trainID === trainID);
    setSelectedTrainUpdate(selected || null); // Handle case when train is not found
    setShowModalUpdate(true);
  };

  const handleUpdateTrain = async () => {
    // Kiểm tra các giá trị cần thiết trong updatedTrain
    const {
      trainID,
      train_name,
      startStation,
      endStation,
      departTime, // 'depart_time' đã được đổi thành 'departTime'
      arrivalTime, // 'arrival_time' đã được đổi thành 'arrivalTime'
      price,
      total_seats,
      start_date,
      end_date,
      duration,
      route_id,
      schedule_id,
      recurrence_id,
      days_of_week,
    } = selectedTrainUpdate!; // ! đảm bảo rằng selectedTrainUpdate luôn có giá trị

    if (!trainID) {
      alert("Train ID is required.");
      return;
    }

    const startDate = new Date(start_date);
    const endDate = new Date(end_date);

    const formattedStartDate = new Date(newTrain.start_date);
    const formattedEndDate = new Date(newTrain.end_date);

    const updatedTrain = {
      ...newTrain,
      start_date: formattedStartDate,
      end_date: formattedEndDate,
    };

    console.log("Updated Train:", updatedTrain); // Debugging the updatedTrain object

    try {
      const response = await fetch("../../app/api/trains", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedTrain),
      });

      const data = await response.json();

      if (response.ok) {
        console.log("Updated train:", updatedTrain);

        setTrainData((prevRecords) => {
          if (Array.isArray(prevRecords)) {
            return prevRecords.map((train) =>
              train.trainID === updatedTrain.trainID
                ? { ...updatedTrain }
                : train
            );
          } else {
            console.error("prevRecords is not an array:", prevRecords);
            return prevRecords;
          }
        });

        alert("Chuyến tàu đã được cập nhật thành công!");
        setShowModalUpdate(false);
      } else {
        console.error("API Error:", data.error);
        alert(data.error || "Cập nhật chuyến tàu thất bại");
      }
    } catch (error) {
      console.error("Error updating train:", error);
      alert("Có lỗi xảy ra khi cập nhật chuyến tàu");
    }
  };

  const columns: ColumnDef<Train>[] = [
    { accessorKey: "trainID", header: "Train ID" },
    { accessorKey: "train_name", header: "Train" },
    { accessorKey: "startStation", header: "Ga đi" },
    { accessorKey: "endStation", header: "Ga đến" },
    { accessorKey: "departTime", header: "Giờ khởi hành" },
    { accessorKey: "price", header: "Giá vé" },
    { accessorKey: "total_seats", header: "Chỗ ngồi" },
    // Add the modal handler in the dropdown menu (for each action).
    {
      id: "actions",
      enableHiding: false,
      header: "Action",
      cell: ({ row }) => {
        const train = row.original;
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>

              {/* Copy Train ID */}
              <DropdownMenuItem
                onClick={() => navigator.clipboard.writeText(train.trainID)}
              >
                Copy Train ID
              </DropdownMenuItem>
              <DropdownMenuSeparator />

              {/* View Train Details */}
              <DropdownMenuItem
                onClick={() => {
                  if (!showModalView) {
                    // Kiểm tra xem modal đã mở chưa
                    handleView(train.trainID); // Show the modal to view the train
                  }
                }}
              >
                View Train Details
              </DropdownMenuItem>

              {/* Update Train Info */}
              <DropdownMenuItem
                onClick={() => {
                  handleUpdate(train.trainID); // Show the modal to update the train
                  setShowModalUpdate(true);
                }}
              >
                Update Train Info
              </DropdownMenuItem>

              {/* Delete Train */}
              <DropdownMenuItem
                onClick={() => handleDelete(train.trainID)} // Trigger the delete function
              >
                Delete Train
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        );
      },
    },
  ];

  const table = useReactTable({
    data: filteredData,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
  });

  if (!isClient) return null;
  if (loading) return <div>Đang tải dữ liệu...</div>;
  if (error) return <div className="text-red-500">{error}</div>;

  return (
    <div className="w-full">
      <div
        className="flex items-center py-4"
        style={{ marginBottom: "20px", justifyContent: "space-between" }}
      >
        <div style={{ position: "relative", width: "300px" }}>
          <input
            type="text"
            placeholder="Search trains..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)} // Cập nhật giá trị khi người dùng nhập
            className={styles.customSearch}
          />
          <FiSearch
            style={{
              position: "absolute",
              right: "24px",
              fontSize: "20px",
              color: "#888",
              cursor: "pointer",
              top: "8px",
            }}
          />
        </div>
        <Button
          style={{ background: "#ff6600", fontWeight: "bold" }}
          onClick={() => setShowModal(true)} // Open the add train modal
        >
          + Add Train
        </Button>
      </div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <TableHead key={header.id}>
                    {header.isPlaceholder
                      ? null
                      : flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  Không có kết quả.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
